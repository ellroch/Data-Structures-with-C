Prof. O'Brien,

hey, There were a number of nodes on the graph that didn't have a name (city / title) so I've attatched a couple .jpg's with the label notation I used in the program.

Changing the Names to letters helped to automate the initialization of the network, hopefully that is acceptable.

